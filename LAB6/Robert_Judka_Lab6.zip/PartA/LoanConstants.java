public interface LoanConstants
{
	final int SHORT = 1;
	final int MEDIUM = 3;
	final int LONG = 5;
	
	final String NAME = "Sanchez Construction Loan Co.";
	final double MAX = 100000;
	
}